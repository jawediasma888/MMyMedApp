# Documentation Schéma BDD — Sprint 4 Administration

**Auteur assigné :** Rayen  
**Fichier SQL :** `database/database.sql`

---

## Tables

### `roles`
| Colonne      | Type         | Description              |
|-------------|-------------|--------------------------|
| id           | INT PK AI    | Identifiant du rôle      |
| nom          | VARCHAR(50)  | `admin`, `medecin`, `patient` |
| description  | VARCHAR(255) | Description textuelle    |

---

### `users`
| Colonne        | Type          | Description                        |
|---------------|---------------|------------------------------------|
| id             | INT PK AI     | Identifiant utilisateur            |
| nom            | VARCHAR(100)  | Nom de famille                     |
| prenom         | VARCHAR(100)  | Prénom                             |
| email          | VARCHAR(191)  | Email unique                       |
| mot_de_passe   | VARCHAR(255)  | Hash bcrypt                        |
| role_id        | INT FK→roles  | Rôle de l'utilisateur              |
| est_actif      | TINYINT(1)    | 1=actif, 0=désactivé               |
| date_creation  | TIMESTAMP     | Date de création du compte         |
| deleted_at     | TIMESTAMP NULL| Soft delete (NULL = non supprimé)  |

---

### `medecins`
| Colonne        | Type         | Description                   |
|---------------|-------------|-------------------------------|
| id             | INT PK AI   | Identifiant médecin            |
| utilisateur_id | INT FK→users| Lien avec le compte utilisateur|
| specialite     | VARCHAR(150)| Spécialité médicale            |
| numero_ordre   | VARCHAR(100)| Numéro d'ordre (optionnel)     |

---

### `patients`
| Colonne          | Type         | Description                   |
|-----------------|-------------|-------------------------------|
| id               | INT PK AI   | Identifiant patient            |
| utilisateur_id   | INT FK→users| Lien avec le compte utilisateur|
| date_naissance   | DATE NULL   | Date de naissance              |
| num_secu_sociale | VARCHAR(20) | Numéro sécurité sociale        |

---

### `rendezvous`
| Colonne    | Type                                          | Description            |
|-----------|----------------------------------------------|------------------------|
| id         | INT PK AI                                    | Identifiant RDV        |
| patient_id | INT FK→patients                              | Patient concerné       |
| medecin_id | INT FK→medecins                              | Médecin concerné       |
| date_heure | DATETIME                                     | Date et heure du RDV   |
| statut     | ENUM(en_attente,confirme,annule,termine)      | Statut actuel          |
| motif      | TEXT NULL                                    | Motif de consultation  |
| created_at | TIMESTAMP                                    | Date de création       |

---

## Trigger — Cascade suppression médecin

Le trigger `trg_before_medecin_softdelete` s'exécute avant toute mise à jour de `users`.  
Quand `deleted_at` passe de `NULL` à une valeur (soft delete), il **annule automatiquement** tous les rendez-vous futurs liés au médecin supprimé, sans toucher aux RDV passés (historique conservé).

---

## Règles d'intégrité

- Un `medecin` et un `patient` héritent d'un `user` via `utilisateur_id` (1-to-1).
- Suppression d'un `user` → cascade sur `medecins` et `patients`.
- Le dernier admin actif ne peut être ni désactivé ni supprimé (contrôle applicatif).
- Soft delete via `deleted_at` recommandé pour tous les utilisateurs.
