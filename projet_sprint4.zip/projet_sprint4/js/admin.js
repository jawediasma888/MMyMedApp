// ============================================================
// admin.js — Scripts communs dashboard & liste utilisateurs
// Auteur assigné : Alee
// ============================================================

const API_BASE = '/api/admin';

// ---- Utilitaires ----

async function apiFetch(url, options = {}) {
  const token = localStorage.getItem('token');
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      ...options.headers,
    },
    ...options,
  });
  if (res.status === 401) {
    window.location.href = '/login';
    return null;
  }
  return res;
}

function showError(msg) {
  alert('Erreur : ' + msg);
}

// ---- Dashboard ----

// admin.js

async function loadDashboardStats() {
  try {
    const res = await apiFetch(`${API_BASE}/stats`);
    if (!res) return;
    
    const data = await res.json();

    // Mise à jour des éléments dans le DOM
    // Assurez-vous que ces IDs existent dans votre dashboard_admin.html
    if (document.getElementById('total-medecins')) {
        document.getElementById('total-medecins').textContent = data.totalMedecins ?? '0';
    }
    if (document.getElementById('total-patients')) {
        document.getElementById('total-patients').textContent = data.totalPatients ?? '0';
    }
    if (document.getElementById('rdv-today')) {
        document.getElementById('rdv-today').textContent = data.rdvToday ?? '0';
    }
    if (document.getElementById('comptes-actifs')) {
        document.getElementById('comptes-actifs').textContent = data.comptesActifs ?? '0';
    }
  } catch (e) {
    console.error('Erreur lors du chargement des statistiques:', e);
  }
}

// Appeler la fonction au chargement de la page
document.addEventListener('DOMContentLoaded', loadDashboardStats);

// ---- Gestion Utilisateurs ----

let allUsers = [];
let pendingDeleteId = null;

async function loadUsers() {
  try {
    const res = await apiFetch(`${API_BASE}/users`);
    if (!res) return;
    allUsers = await res.json();
    renderUsers(allUsers);
  } catch (e) {
    console.error('Erreur chargement utilisateurs', e);
  }
}

function renderUsers(users) {
  const tbody = document.getElementById('users-body');
  if (!tbody) return;
  tbody.innerHTML = users.map(u => `
    <tr>
      <td>${u.nom} ${u.prenom}</td>
      <td>${u.email}</td>
      <td><span class="badge badge-role">${u.role}</span></td>
      <td><span class="badge ${u.est_actif ? 'badge-active' : 'badge-inactive'}">${u.est_actif ? 'Actif' : 'Inactif'}</span></td>
      <td>
        <button class="btn-sm btn-edit" onclick="openEditUserModal(${u.id})">✏️</button>
        <button class="btn-sm btn-toggle" onclick="toggleUser(${u.id}, ${u.est_actif})">${u.est_actif ? '🔒' : '🔓'}</button>
        <button class="btn-sm btn-delete" onclick="confirmDelete(${u.id})">🗑️</button>
      </td>
    </tr>
  `).join('');
}

function applyFilters() {
  const role = document.getElementById('filter-role')?.value || '';
  const status = document.getElementById('filter-status')?.value || '';
  const search = document.getElementById('search-input')?.value.toLowerCase() || '';

  const filtered = allUsers.filter(u => {
    const matchRole = !role || u.role === role;
    const matchStatus = status === '' || String(u.est_actif ? 1 : 0) === status;
    const matchSearch = !search || `${u.nom} ${u.prenom} ${u.email}`.toLowerCase().includes(search);
    return matchRole && matchStatus && matchSearch;
  });

  renderUsers(filtered);
}

async function toggleUser(id, currentStatus) {
  try {
    const res = await apiFetch(`${API_BASE}/toggle-user`, {
      method: 'POST',
      body: JSON.stringify({ user_id: id }),
    });
    if (!res) return;
    const data = await res.json();
    if (data.success) {
      await loadUsers();
    } else {
      showError(data.message || 'Erreur lors du changement de statut');
    }
  } catch (e) {
    showError('Erreur réseau');
  }
}

// ---- Modal suppression ----

function confirmDelete(id) {
  pendingDeleteId = id;
  document.getElementById('confirm-modal').classList.remove('hidden');
  document.getElementById('confirm-delete-btn').onclick = () => deleteUser(id);
}

function closeConfirmModal() {
  pendingDeleteId = null;
  document.getElementById('confirm-modal').classList.add('hidden');
}

async function deleteUser(id) {
  closeConfirmModal();
  try {
    const res = await apiFetch(`${API_BASE}/users/${id}`, { method: 'DELETE' });
    if (!res) return;
    const data = await res.json();
    if (data.success) {
      await loadUsers();
    } else {
      showError(data.message || 'Erreur suppression');
    }
  } catch (e) {
    showError('Erreur réseau');
  }
}

// ---- Modal ajout/édition utilisateur ----

let editingUserId = null;

function openAddModal() {
  editingUserId = null;
  document.getElementById('modal-title').textContent = 'Ajouter un utilisateur';
  clearUserForm();
  document.getElementById('form-modal').classList.remove('hidden');
  document.getElementById('modal-save-btn').onclick = saveUser;
}

function openEditUserModal(id) {
  const user = allUsers.find(u => u.id === id);
  if (!user) return;
  editingUserId = id;
  document.getElementById('modal-title').textContent = 'Modifier l\'utilisateur';
  document.getElementById('input-nom').value = user.nom;
  document.getElementById('input-prenom').value = user.prenom;
  document.getElementById('input-email').value = user.email;
  document.getElementById('input-role').value = user.role;
  document.getElementById('form-modal').classList.remove('hidden');
  document.getElementById('modal-save-btn').onclick = saveUser;
}

function closeFormModal() {
  document.getElementById('form-modal').classList.add('hidden');
}

function clearUserForm() {
  ['input-nom', 'input-prenom', 'input-email'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
}

async function saveUser() {
  const nom = document.getElementById('input-nom').value.trim();
  const prenom = document.getElementById('input-prenom').value.trim();
  const email = document.getElementById('input-email').value.trim();
  const role = document.getElementById('input-role').value;

  if (!nom || !prenom || !email) {
    showError('Veuillez remplir tous les champs obligatoires');
    return;
  }

  const payload = { nom, prenom, email, role };
  const url = editingUserId ? `${API_BASE}/users/${editingUserId}` : `${API_BASE}/users`;
  const method = editingUserId ? 'PUT' : 'POST';

  try {
    const res = await apiFetch(url, { method, body: JSON.stringify(payload) });
    if (!res) return;
    const data = await res.json();
    if (data.success) {
      closeFormModal();
      await loadUsers();
    } else {
      showError(data.message || 'Erreur sauvegarde');
    }
  } catch (e) {
    showError('Erreur réseau');
  }
}

// ---- Init ----

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('total-medecins')) loadDashboardStats();
  if (document.getElementById('users-body')) loadUsers();
});
