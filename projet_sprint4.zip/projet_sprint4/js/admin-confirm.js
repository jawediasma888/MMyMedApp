// ============================================================
// admin-confirm.js — Modale de confirmation générique
// Auteur assigné : Asma
// ============================================================

/**
 * Affiche une modale de confirmation personnalisable.
 * @param {string} message - Message à afficher.
 * @param {Function} onConfirm - Callback exécuté à la confirmation.
 * @param {string} confirmLabel - Texte du bouton de confirmation.
 */
function showConfirmModal(message, onConfirm, confirmLabel = 'Confirmer') {
  let modal = document.getElementById('generic-confirm-modal');

  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'generic-confirm-modal';
    modal.className = 'modal';
    modal.innerHTML = `
      <div class="modal-box">
        <p id="confirm-msg"></p>
        <div class="modal-actions">
          <button class="btn-danger" id="generic-confirm-btn"></button>
          <button class="btn-secondary" id="generic-cancel-btn">Annuler</button>
        </div>
      </div>`;
    document.body.appendChild(modal);

    document.getElementById('generic-cancel-btn').onclick = () => {
      modal.classList.add('hidden');
    };
  }

  document.getElementById('confirm-msg').textContent = message;
  const confirmBtn = document.getElementById('generic-confirm-btn');
  confirmBtn.textContent = confirmLabel;
  confirmBtn.onclick = () => {
    modal.classList.add('hidden');
    onConfirm();
  };

  modal.classList.remove('hidden');
}
