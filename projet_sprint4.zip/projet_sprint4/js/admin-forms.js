// ============================================================
// admin-forms.js — Formulaires médecin (ajout/édition/suppression)
// Auteur : Asma (Corrigé)
// ============================================================

let editingMedecinId = null;
let allMedecins = [];

/**
 * Fonction utilitaire pour les appels API (si non définie ailleurs)
 * Assurez-vous que le jeton JWT est inclus ici.
 */
async function apiFetch(url, options = {}) {
    const token = localStorage.getItem('token');
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token ? `Bearer ${token}` : ''
        }
    };
    
    // On combine les options par défaut avec celles passées en argument
    const mergedOptions = { ...defaultOptions, ...options };
    if (options.headers) {
        mergedOptions.headers = { ...defaultOptions.headers, ...options.headers };
    }

    const response = await fetch(url, mergedOptions);
    if (response.status === 401) {
        alert("Session expirée, veuillez vous reconnecter.");
        window.location.href = '/login.html';
        return null;
    }
    return response;
}

// ---- Chargement liste médecins ----

async function loadMedecins() {
  try {
    // CORRECTION : Ajout de .php si votre serveur ne gère pas la réécriture
    const res = await apiFetch('../../api/admin/medecins.php'); 
    if (!res) return;
    allMedecins = await res.json();
    renderMedecins(allMedecins);
  } catch (e) {
    console.error('Erreur chargement médecins', e);
  }
}

function renderMedecins(medecins) {
  const tbody = document.getElementById('medecins-body');
  if (!tbody) return;
  
  if (medecins.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center">Aucun médecin trouvé</td></tr>';
    return;
  }

  tbody.innerHTML = medecins.map(m => `
    <tr>
      <td>${m.nom}</td>
      <td>${m.prenom}</td>
      <td>${m.specialite}</td>
      <td>${m.email}</td>
      <td><span class="badge ${m.est_actif ? 'badge-active' : 'badge-inactive'}">${m.est_actif ? 'Actif' : 'Inactif'}</span></td>
      <td>
        <button class="btn-sm btn-edit" onclick="openMedecinForm(${m.id})">✏️ Modifier</button>
        <button class="btn-sm btn-delete" onclick="confirmDeleteMedecin(${m.id})">🗑️ Supprimer</button>
      </td>
    </tr>
  `).join('');
}

// ---- Modal formulaire ----

function openMedecinForm(id = null) {
  editingMedecinId = id;
  const modal = document.getElementById('medecin-modal');
  const title = document.getElementById('medecin-modal-title');
  if (!modal) return;

  clearMedecinForm();

  if (id) {
    // Correction : s'assurer qu'on cherche l'id numérique
    const med = allMedecins.find(m => parseInt(m.id) === parseInt(id));
    if (!med) return;
    
    title.textContent = 'Modifier le médecin';
    document.getElementById('med-nom').value = med.nom;
    document.getElementById('med-prenom').value = med.prenom;
    document.getElementById('med-specialite').value = med.specialite;
    document.getElementById('med-email').value = med.email;
    if(document.getElementById('med-telephone')) document.getElementById('med-telephone').value = med.telephone || '';
    if(document.getElementById('med-numero-ordre')) document.getElementById('med-numero-ordre').value = med.numero_ordre || '';
    
    const pwdGroup = document.getElementById('group-password');
    if(pwdGroup) pwdGroup.style.display = 'none';
  } else {
    title.textContent = 'Ajouter un médecin';
    const pwdGroup = document.getElementById('group-password');
    if(pwdGroup) pwdGroup.style.display = 'block';
  }

  modal.classList.remove('hidden');
}

function closeMedecinForm() {
  const modal = document.getElementById('medecin-modal');
  if(modal) modal.classList.add('hidden');
  editingMedecinId = null;
}

function clearMedecinForm() {
  const fields = ['med-nom', 'med-prenom', 'med-specialite', 'med-email', 'med-telephone', 'med-numero-ordre', 'med-password'];
  fields.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  
  const errors = ['err-nom', 'err-prenom', 'err-specialite', 'err-email', 'err-password'];
  errors.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.textContent = '';
  });
}

// ---- Validation côté client ----

function validateMedecinForm() {
  let valid = true;

  const fields = {
    nom: 'med-nom',
    prenom: 'med-prenom',
    specialite: 'med-specialite',
    email: 'med-email'
  };

  for (let key in fields) {
    const val = document.getElementById(fields[key]).value.trim();
    const errEl = document.getElementById('err-' + key);
    if (!val) {
        if(errEl) errEl.textContent = 'Champ obligatoire';
        valid = false;
    } else if(errEl) {
        errEl.textContent = '';
    }
  }

  const email = document.getElementById('med-email').value.trim();
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    document.getElementById('err-email').textContent = 'Format email invalide';
    valid = false;
  }

  if (!editingMedecinId) {
    const pwd = document.getElementById('med-password').value;
    if (!pwd) {
        document.getElementById('err-password').textContent = 'Mot de passe obligatoire';
        valid = false;
    }
  }

  return valid;
}

// ---- Sauvegarde médecin ----

async function saveMedecin() {
  if (!validateMedecinForm()) return;

  const payload = {
    nom: document.getElementById('med-nom').value.trim(),
    prenom: document.getElementById('med-prenom').value.trim(),
    specialite: document.getElementById('med-specialite').value.trim(),
    email: document.getElementById('med-email').value.trim(),
    numero_ordre: document.getElementById('med-numero-ordre') ? document.getElementById('med-numero-ordre').value.trim() : ''
  };

  if (!editingMedecinId) {
    payload.password = document.getElementById('med-password').value;
  }

  // CORRECTION : URL pointant vers le fichier .php réel
  const baseUrl = '../../api/admin/medecins.php';
  const url = editingMedecinId ? `${baseUrl}/${editingMedecinId}` : baseUrl;
  const method = editingMedecinId ? 'PUT' : 'POST';

  try {
    const res = await apiFetch(url, { method, body: JSON.stringify(payload) });
    if (!res) return;

    const data = await res.json();
    if (data.success) {
      closeMedecinForm();
      await loadMedecins();
    } else {
      alert('Erreur : ' + (data.message || 'Échec de l\'opération'));
    }
  } catch (e) {
    console.error(e);
    alert('Erreur réseau ou serveur');
  }
}

// ---- Suppression médecin ----

function confirmDeleteMedecin(id) {
  const modal = document.getElementById('confirm-modal');
  if(!modal) return;
  modal.classList.remove('hidden');
  document.getElementById('confirm-delete-btn').onclick = () => deleteMedecin(id);
}

async function deleteMedecin(id) {
  document.getElementById('confirm-modal').classList.add('hidden');
  try {
    const res = await apiFetch(`../../api/admin/medecins.php/${id}`, { method: 'DELETE' });
    if (!res) return;
    const data = await res.json();
    if (data.success) {
      await loadMedecins();
    } else {
      alert('Erreur : ' + (data.message || 'Erreur suppression'));
    }
  } catch (e) {
    alert('Erreur réseau');
  }
}

// ---- Init ----

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('medecins-body')) {
      loadMedecins();
  }
  
  // Attacher l'événement au bouton de sauvegarde du modal
  const saveBtn = document.getElementById('med-save-btn');
  if(saveBtn) {
      saveBtn.onclick = saveMedecin;
  }
});