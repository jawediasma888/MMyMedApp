<?php
// ============================================================
// config/jwt.php — Génération et vérification JWT (HS256)
// ============================================================

// CORRECTION : On définit une clé en dur ou via une constante stable
// Assure-toi que cette clé est LA MÊME dans tout ton projet.
if (!defined('JWT_SECRET')) {
    define('JWT_SECRET', 'votre_cle_tres_securisee_123456'); 
}
define('JWT_EXPIRY', 3600); // 1 heure

function base64urlEncode(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64urlDecode(string $data): string {
    $remainder = strlen($data) % 4;
    if ($remainder) {
        $data .= str_repeat('=', 4 - $remainder);
    }
    return base64_decode(strtr($data, '-_', '+/'));
}

/**
 * Génère un Token. 
 * IMPORTANT : Le payload DOIT contenir 'sub' (l'ID de l'utilisateur)
 */
function generateJWT(array $payload): string {
    $header = base64urlEncode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    
    $payload['iat'] = time();
    $payload['exp'] = time() + JWT_EXPIRY;
    
    $payloadEnc = base64urlEncode(json_encode($payload));
    $signature  = base64urlEncode(hash_hmac('sha256', "$header.$payloadEnc", JWT_SECRET, true));
    
    return "$header.$payloadEnc.$signature";
}

/**
 * Vérifie le Token
 */
function verifyJWT(string $token): array {
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        throw new Exception('Token malformé : format invalide');
    }

    [$header, $payloadEnc, $signature] = $parts;

    // Vérification de la signature
    $expectedSignature = base64urlEncode(hash_hmac('sha256', "$header.$payloadEnc", JWT_SECRET, true));

    if (!hash_equals($expectedSignature, $signature)) {
        throw new Exception('Signature invalide : la clé secrète ne correspond pas');
    }

    $data = json_decode(base64urlDecode($payloadEnc), true);
    
    if (!$data) {
        throw new Exception('Payload invalide : impossible de lire les données');
    }

    // Vérification de l'expiration
    if (isset($data['exp']) && $data['exp'] < time()) {
        throw new Exception('Token expiré : merci de vous reconnecter');
    }

    return $data;
}