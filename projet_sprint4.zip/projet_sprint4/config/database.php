<?php
// ============================================================
// config/database.php — Connexion PDO
// ============================================================

function getDB(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;

    // CORRECTION : Utilisation de variables directes ou constantes 
    // pour éviter les problèmes de configuration serveur (getenv)
    $host   = 'localhost';
    $dbname = 'mediplat';
    $user   = 'root';
    $pass   = '';
    $port   = '3306';

    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";

    try {
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        // CORRECTION : Message d'erreur clair si la BD n'est pas lancée
        http_response_code(500);
        die(json_encode([
            'success' => false, 
            'message' => 'Erreur de connexion à la base de données : ' . $e->getMessage()
        ]));
    }
}