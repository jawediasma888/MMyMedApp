-- ============================================================
-- database.sql — Schéma BDD complet (Sprint 1-4)
-- Auteur assigné : Rayen
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---- Rôles ----
CREATE TABLE IF NOT EXISTS `roles` (
    `id`          INT AUTO_INCREMENT PRIMARY KEY,
    `nom`         VARCHAR(50) NOT NULL UNIQUE,
    `description` VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `roles` (`nom`, `description`) VALUES
    ('medecin', 'Médecin inscrit sur la plateforme'),
    ('patient', 'Patient utilisateur');

-- ---- Utilisateurs ----
CREATE TABLE IF NOT EXISTS `users` (
    `id`             INT AUTO_INCREMENT PRIMARY KEY,
    `nom`            VARCHAR(100)        NOT NULL,
    `prenom`         VARCHAR(100)        NOT NULL,
    `email`          VARCHAR(191)        NOT NULL UNIQUE,
    `mot_de_passe`   VARCHAR(255)        NOT NULL,
    `role_id`        INT                 NOT NULL,
    `est_actif`      TINYINT(1)          NOT NULL DEFAULT 1,
    `date_creation`  TIMESTAMP           NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `deleted_at`     TIMESTAMP           NULL DEFAULT NULL,
    CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- Médecins ----
CREATE TABLE IF NOT EXISTS `medecins` (
    `id`              INT AUTO_INCREMENT PRIMARY KEY,
    `utilisateur_id`  INT          NOT NULL UNIQUE,
    `specialite`      VARCHAR(150) NOT NULL,
    `numero_ordre`    VARCHAR(100) NULL,
    CONSTRAINT `fk_medecins_user` FOREIGN KEY (`utilisateur_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- Patients ----
CREATE TABLE IF NOT EXISTS `patients` (
    `id`               INT AUTO_INCREMENT PRIMARY KEY,
    `utilisateur_id`   INT         NOT NULL UNIQUE,
    `date_naissance`   DATE        NULL,
    `num_secu_sociale` VARCHAR(20) NULL,
    CONSTRAINT `fk_patients_user` FOREIGN KEY (`utilisateur_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- Rendez-vous ----
CREATE TABLE IF NOT EXISTS `rendezvous` (
    `id`          INT AUTO_INCREMENT PRIMARY KEY,
    `patient_id`  INT          NOT NULL,
    `medecin_id`  INT          NOT NULL,
    `date_heure`  DATETIME     NOT NULL,
    `statut`      ENUM('en_attente','confirme','annule','termine') NOT NULL DEFAULT 'en_attente',
    `motif`       TEXT         NULL,
    `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_rdv_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`),
    CONSTRAINT `fk_rdv_medecin` FOREIGN KEY (`medecin_id`) REFERENCES `medecins`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- Gestion cascade suppression médecin (ON DELETE) — Rayen ----
-- Trigger : lors de la suppression (soft delete) d'un médecin,
--           annuler ses RDV futurs et conserver les RDV passés.

DELIMITER $$

CREATE TRIGGER IF NOT EXISTS `trg_before_medecin_softdelete`
BEFORE UPDATE ON `users`
FOR EACH ROW
BEGIN
    -- Déclenché quand deleted_at passe de NULL à une valeur (soft delete)
    IF OLD.deleted_at IS NULL AND NEW.deleted_at IS NOT NULL THEN
        -- Annuler les RDV futurs liés à ce médecin
        UPDATE `rendezvous` rdv
        JOIN `medecins` m ON rdv.medecin_id = m.id
        SET rdv.statut = 'annule'
        WHERE m.utilisateur_id = OLD.id
          AND rdv.date_heure > NOW()
          AND rdv.statut NOT IN ('annule', 'termine');
    END IF;
END$$

DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;
