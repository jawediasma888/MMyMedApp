<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

// Note : Si vous supprimez le rôle admin en BDD, assurez-vous que 
// le fichier middleware/admin.php ne bloque pas l'accès.
require_once __DIR__ . '/../../middleware/admin.php'; 
require_once __DIR__ . '/../../config/database.php';

// Si vous avez supprimé le rôle admin, cette fonction adminOnly() 
// devra probablement être renommée ou modifiée dans son fichier source.
$userAuthenticated = adminOnly(); 
$pdo = getDB();

$method = $_SERVER['REQUEST_METHOD'];
$uri = $_SERVER['REQUEST_URI'];

preg_match('/\/users\/?(\d+)?/', $uri, $matches);
$id = isset($matches[1]) ? (int)$matches[1] : null;

// ---- GET /api/admin/users ----
if ($method === 'GET' && !$id) {
    $role   = $_GET['role'] ?? null;
    $status = $_GET['status'] ?? null;

    $where = ['u.deleted_at IS NULL'];
    $params = [];

    if ($role) { $where[] = 'r.nom = :role'; $params[':role'] = $role; }
    if ($status !== null) { $where[] = 'u.est_actif = :status'; $params[':status'] = (int)$status; }

    $sql = "
        SELECT u.id, u.nom, u.prenom, u.email, u.est_actif, u.date_creation, r.nom AS role
        FROM users u
        JOIN roles r ON u.role_id = r.id
        WHERE " . implode(' AND ', $where) . "
        ORDER BY u.date_creation DESC
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// ---- GET /api/admin/users/:id ----
if ($method === 'GET' && $id) {
    $stmt = $pdo->prepare("
        SELECT u.id, u.nom, u.prenom, u.email, u.est_actif, r.nom AS role
        FROM users u JOIN roles r ON u.role_id = r.id
        WHERE u.id = :id AND u.deleted_at IS NULL
    ");
    $stmt->execute([':id' => $id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) { http_response_code(404); echo json_encode(['success' => false, 'message' => 'Introuvable']); exit; }
    echo json_encode($user);
    exit;
}

// ---- POST /api/admin/users ----
if ($method === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true);
    foreach (['nom', 'prenom', 'email', 'role', 'password'] as $f) {
        if (empty($body[$f])) {
            http_response_code(400); echo json_encode(['success' => false, 'message' => "Champ manquant : $f"]); exit;
        }
    }

    if (!filter_var($body['email'], FILTER_VALIDATE_EMAIL)) {
        http_response_code(400); echo json_encode(['success' => false, 'message' => 'Email invalide']); exit;
    }

    $chk = $pdo->prepare("SELECT id FROM users WHERE email = :email AND deleted_at IS NULL");
    $chk->execute([':email' => $body['email']]);
    if ($chk->fetch()) { http_response_code(409); echo json_encode(['success' => false, 'message' => 'Email déjà utilisé']); exit; }

    $roleStmt = $pdo->prepare("SELECT id FROM roles WHERE nom = :nom");
    $roleStmt->execute([':nom' => $body['role']]);
    $roleId = $roleStmt->fetchColumn();
    if (!$roleId) { http_response_code(400); echo json_encode(['success' => false, 'message' => 'Rôle invalide']); exit; }

    $stmt = $pdo->prepare("
        INSERT INTO users (nom, prenom, email, mot_de_passe, role_id, est_actif, date_creation)
        VALUES (:nom, :prenom, :email, :pwd, :role_id, 1, NOW())
    ");
    $stmt->execute([
        ':nom' => $body['nom'], ':prenom' => $body['prenom'],
        ':email' => $body['email'],
        ':pwd' => password_hash($body['password'], PASSWORD_BCRYPT),
        ':role_id' => $roleId,
    ]);
    http_response_code(201);
    echo json_encode(['success' => true, 'message' => 'Utilisateur créé', 'id' => $pdo->lastInsertId()]);
    exit;
}

// ---- PUT /api/admin/users/:id ----
if ($method === 'PUT' && $id) {
    $body = json_decode(file_get_contents('php://input'), true);

    $chk = $pdo->prepare("SELECT id FROM users WHERE id = :id AND deleted_at IS NULL");
    $chk->execute([':id' => $id]);
    if (!$chk->fetch()) { http_response_code(404); echo json_encode(['success' => false, 'message' => 'Introuvable']); exit; }

    // Mise à jour simplifiée sans vérification de rôle admin spécifique
    $fields = []; $params = [':id' => $id];
    foreach (['nom', 'prenom', 'email', 'est_actif'] as $f) {
        if (isset($body[$f])) { $fields[] = "$f = :$f"; $params[":$f"] = $body[$f]; }
    }
    
    if (!empty($body['role'])) {
        $roleStmt = $pdo->prepare("SELECT id FROM roles WHERE nom = :nom");
        $roleStmt->execute([':nom' => $body['role']]);
        $roleId = $roleStmt->fetchColumn();
        if ($roleId) { $fields[] = 'role_id = :role_id'; $params[':role_id'] = $roleId; }
    }

    if ($fields) {
        $pdo->prepare("UPDATE users SET " . implode(', ', $fields) . " WHERE id = :id")->execute($params);
    }
    echo json_encode(['success' => true, 'message' => 'Utilisateur mis à jour']);
    exit;
}

// ---- DELETE /api/admin/users/:id ----
if ($method === 'DELETE' && $id) {
    // Suppression de toute la logique "adminCount" qui protégeait le rôle admin
    $stmt = $pdo->prepare("UPDATE users SET deleted_at = NOW(), est_actif = 0 WHERE id = :id");
    $stmt->execute([':id' => $id]);
    echo json_encode(['success' => true, 'message' => 'Utilisateur supprimé']);
    exit;
}

http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Requête invalide']);