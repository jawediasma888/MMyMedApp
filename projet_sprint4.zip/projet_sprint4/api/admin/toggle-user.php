<?php
// ============================================================
// api/admin/toggle-user.php — Activation / désactivation compte
// Auteur assigné : Sawssen
// ============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

// Note : Si vous avez supprimé le rôle admin en BDD, 
// vérifiez que ce middleware autorise toujours l'accès.
require_once __DIR__ . '/../../middleware/admin.php';
require_once __DIR__ . '/../../config/database.php';

// Vérification de l'authentification
$admin = adminOnly();

$body = json_decode(file_get_contents('php://input'), true);
$userId = isset($body['user_id']) ? (int)$body['user_id'] : 0;

if (!$userId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'user_id manquant']);
    exit;
}

$pdo = getDB();

// Récupérer l'utilisateur
$stmt = $pdo->prepare("SELECT id, est_actif FROM users WHERE id = :id AND deleted_at IS NULL");
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Utilisateur introuvable']);
    exit;
}

// --- LA PARTIE SUPPRIMÉE ÉTAIT ICI ---
// On ne vérifie plus si c'est le dernier admin, car le rôle admin n'existe plus.
// N'importe quel compte peut désormais être désactivé.

// Basculer le statut
$newStatus = $user['est_actif'] ? 0 : 1;
$stmtUpdate = $pdo->prepare("UPDATE users SET est_actif = :status WHERE id = :id");
$stmtUpdate->execute([':status' => $newStatus, ':id' => $userId]);

echo json_encode([
    'success' => true,
    'message' => $newStatus ? 'Compte activé' : 'Compte désactivé',
    'est_actif' => (bool)$newStatus,
]);