<?php
// ============================================================
// api/admin/medecins.php — CRUD complet médecins
// Auteur assigné : Yahya (Optimisé)
// ============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

require_once __DIR__ . '/../../middleware/admin.php';
require_once __DIR__ . '/../../config/database.php';

$userAuthenticated = adminOnly();
$pdo = getDB();

$method = $_SERVER['REQUEST_METHOD'];
// CORRECTION : Nettoyage de l'URI pour éviter les erreurs d'extraction d'ID
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$parts = explode('/', trim($uri, '/'));
// On récupère le dernier segment s'il est numérique
$id = (isset($parts[3]) && is_numeric($parts[3])) ? (int)$parts[3] : null;

// ---- GET /api/admin/medecins ----
if ($method === 'GET' && !$id) {
    $stmt = $pdo->query("
        SELECT u.id, u.nom, u.prenom, u.email, u.est_actif, u.date_creation,
               m.specialite, m.numero_ordre, m.id AS medecin_id
        FROM users u
        JOIN medecins m ON m.utilisateur_id = u.id
        WHERE u.deleted_at IS NULL
        ORDER BY u.nom, u.prenom
    ");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// ---- GET /api/admin/medecins/:id ----
if ($method === 'GET' && $id) {
    $stmt = $pdo->prepare("
        SELECT u.id, u.nom, u.prenom, u.email, u.est_actif,
               m.specialite, m.numero_ordre
        FROM users u
        JOIN medecins m ON m.utilisateur_id = u.id
        WHERE u.id = :id AND u.deleted_at IS NULL
    ");
    $stmt->execute([':id' => $id]);
    $med = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$med) { http_response_code(404); echo json_encode(['success' => false, 'message' => 'Médecin introuvable']); exit; }
    echo json_encode($med);
    exit;
}

// ---- POST /api/admin/medecins ----
if ($method === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true);
    $required = ['nom', 'prenom', 'email', 'specialite', 'password'];
    foreach ($required as $field) {
        if (empty($body[$field])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => "Champ manquant : $field"]);
            exit;
        }
    }

    if (!filter_var($body['email'], FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Format email invalide']);
        exit;
    }

    $checkEmail = $pdo->prepare("SELECT id FROM users WHERE email = :email AND deleted_at IS NULL");
    $checkEmail->execute([':email' => $body['email']]);
    if ($checkEmail->fetch()) {
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => 'Email déjà utilisé']);
        exit;
    }

    $roleStmt = $pdo->prepare("SELECT id FROM roles WHERE nom = 'medecin'");
    $roleStmt->execute();
    $roleId = $roleStmt->fetchColumn();
    
    // CORRECTION : Sécurité si le rôle n'existe pas en base
    if (!$roleId) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Rôle médecin non configuré en base de données']);
        exit;
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("
            INSERT INTO users (nom, prenom, email, mot_de_passe, role_id, est_actif, date_creation)
            VALUES (:nom, :prenom, :email, :password, :role_id, 1, NOW())
        ");
        $stmt->execute([
            ':nom'      => $body['nom'],
            ':prenom'   => $body['prenom'],
            ':email'    => $body['email'],
            ':password' => password_hash($body['password'], PASSWORD_BCRYPT),
            ':role_id'  => $roleId,
        ]);
        $userId = $pdo->lastInsertId();

        $stmtMed = $pdo->prepare("
            INSERT INTO medecins (utilisateur_id, specialite, numero_ordre)
            VALUES (:uid, :specialite, :numero_ordre)
        ");
        $stmtMed->execute([
            ':uid'          => $userId,
            ':specialite'   => $body['specialite'],
            ':numero_ordre' => $body['numero_ordre'] ?? null,
        ]);

        $pdo->commit();
        http_response_code(201);
        echo json_encode(['success' => true, 'message' => 'Médecin créé', 'id' => $userId]);
    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Erreur serveur SQL']);
    }
    exit;
}

// ---- PUT /api/admin/medecins/:id ----
if ($method === 'PUT' && $id) {
    $body = json_decode(file_get_contents('php://input'), true);

    $check = $pdo->prepare("SELECT u.id FROM users u JOIN medecins m ON m.utilisateur_id = u.id WHERE u.id = :id AND u.deleted_at IS NULL");
    $check->execute([':id' => $id]);
    if (!$check->fetch()) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Médecin introuvable']);
        exit;
    }

    $pdo->beginTransaction();
    try {
        $fields = [];
        $params = [':id' => $id];
        foreach (['nom', 'prenom', 'email'] as $f) {
            if (isset($body[$f])) { $fields[] = "$f = :$f"; $params[":$f"] = $body[$f]; }
        }
        if ($fields) {
            $pdo->prepare("UPDATE users SET " . implode(', ', $fields) . " WHERE id = :id")->execute($params);
        }

        $medFields = [];
        $medParams = [':uid' => $id];
        foreach (['specialite', 'numero_ordre'] as $f) {
            if (isset($body[$f])) { $medFields[] = "$f = :$f"; $medParams[":$f"] = $body[$f]; }
        }
        if ($medFields) {
            $pdo->prepare("UPDATE medecins SET " . implode(', ', $medFields) . " WHERE utilisateur_id = :uid")->execute($medParams);
        }

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Médecin mis à jour']);
    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Erreur lors de la mise à jour']);
    }
    exit;
}

// ---- DELETE /api/admin/medecins/:id ----
if ($method === 'DELETE' && $id) {
    $stmt = $pdo->prepare("UPDATE users SET deleted_at = NOW(), est_actif = 0 WHERE id = :id");
    $stmt->execute([':id' => $id]);
    echo json_encode(['success' => true, 'message' => 'Médecin supprimé']);
    exit;
}

http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Requête invalide ou ID manquant']);