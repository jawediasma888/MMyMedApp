# Tests CRUD Admin (Médecins & Utilisateurs)

**Auteur assigné :** Mouhib  
**Sprint :** Sprint 4 — Administration  
**Fichier :** `tests/admin-tests.md`

---

## Prérequis

- Serveur PHP/MySQL actif
- Token JWT valide pour un compte `admin`
- Base de données migrée (`database/database.sql`)

---

## Variables de test

```
BASE_URL = http://localhost/api/admin
TOKEN    = <jwt_admin_valide>
```

---

## 1. Tests Médecins

### 1.1 Créer un médecin (POST /medecins)

**Cas nominal ✅**
```http
POST /api/admin/medecins
Authorization: Bearer {{TOKEN}}
Content-Type: application/json

{
  "nom": "Trabelsi",
  "prenom": "Sami",
  "email": "sami.trabelsi@clinic.tn",
  "specialite": "Cardiologie",
  "password": "Test@1234",
  "numero_ordre": "ORD-1234"
}
```
> Résultat attendu : `201 Created` + `{ "success": true, "id": <N> }`

---

**Email en double ❌**
```http
POST /api/admin/medecins
{ ...même email... }
```
> Résultat attendu : `409 Conflict` + `{ "success": false, "message": "Email déjà utilisé" }`

---

**Champ obligatoire manquant ❌**
```http
POST /api/admin/medecins
{ "nom": "Trabelsi" }  ← email et specialite absents
```
> Résultat attendu : `400 Bad Request`

---

### 1.2 Lire la liste (GET /medecins)

```http
GET /api/admin/medecins
Authorization: Bearer {{TOKEN}}
```
> Résultat attendu : `200 OK` + tableau JSON avec tous les médecins actifs

---

### 1.3 Modifier un médecin (PUT /medecins/:id)

**Cas nominal ✅**
```http
PUT /api/admin/medecins/{{id}}
{ "specialite": "Neurologie" }
```
> Résultat attendu : `200 OK` + `{ "success": true }`  
> Vérification : spécialité mise à jour, RDV existants non affectés

---

**ID inexistant ❌**
```http
PUT /api/admin/medecins/99999
{ "specialite": "X" }
```
> Résultat attendu : `404 Not Found`

---

### 1.4 Supprimer un médecin (DELETE /medecins/:id)

**Cas nominal ✅**
```http
DELETE /api/admin/medecins/{{id}}
```
> Résultat attendu : `200 OK` + `{ "success": true }`  
> Vérification : `deleted_at` renseigné en BDD, RDV futurs passés à `annule`, RDV passés conservés

---

---

## 2. Tests Utilisateurs

### 2.1 Créer un utilisateur (POST /users)

**Cas nominal ✅**
```http
POST /api/admin/users
{ "nom": "Ben Ali", "prenom": "Leila", "email": "leila@test.tn", "role": "patient", "password": "Test@1234" }
```
> Résultat attendu : `201 Created`

---

**Sans token ❌**
```http
POST /api/admin/users  ← sans Authorization
```
> Résultat attendu : `401 Unauthorized`

---

**Avec token non-admin ❌**
```http
POST /api/admin/users
Authorization: Bearer {{TOKEN_PATIENT}}
```
> Résultat attendu : `403 Forbidden`

---

### 2.2 Activer / désactiver (POST /toggle-user)

**Cas nominal ✅**
```http
POST /api/admin/toggle-user
{ "user_id": {{id}} }
```
> Résultat attendu : `200 OK` + statut basculé

---

**Désactiver le dernier admin ❌**
```http
POST /api/admin/toggle-user
{ "user_id": 1 }  ← seul admin actif
```
> Résultat attendu : `400 Bad Request` + message explicite

---

### 2.3 Filtrage liste utilisateurs

```http
GET /api/admin/users?role=medecin&status=1
```
> Résultat attendu : uniquement les médecins actifs

---

## 3. Checklist d'intégration

| Test                                          | Statut |
|----------------------------------------------|--------|
| Ajout médecin → profil accessible immédiatement | ☐      |
| Modification médecin → RDV existants inchangés  | ☐      |
| Suppression médecin → RDV futurs annulés        | ☐      |
| Suppression médecin → RDV passés conservés      | ☐      |
| Toggle user → statut mis à jour dans UI         | ☐      |
| Accès sans token → 401                          | ☐      |
| Accès avec token patient → 403                  | ☐      |
| Dernier admin protégé contre suppression        | ☐      |
