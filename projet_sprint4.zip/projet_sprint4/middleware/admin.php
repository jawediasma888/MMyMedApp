<?php
// ============================================================
// middleware/admin.php — Middleware accès sécurisé
// ============================================================

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/jwt.php';

function adminOnly(): array {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? '';

    if (!str_starts_with($authHeader, 'Bearer ')) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Token manquant']);
        exit;
    }

    $token = substr($authHeader, 7);

    try {
        $payload = verifyJWT($token);
    } catch (Exception $e) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Token invalide ou expiré']);
        exit;
    }

    $pdo = getDB();
    $stmt = $pdo->prepare("
        SELECT u.id, u.nom, u.prenom, u.email, u.est_actif, r.nom AS role
        FROM users u
        LEFT JOIN roles r ON u.role_id = r.id
        WHERE u.id = :id AND u.est_actif = 1 AND u.deleted_at IS NULL
    ");
    $stmt->execute([':id' => $payload['sub']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Compte invalide ou inactif']);
        exit;
    }

    // CORRECTION : Protection contre les accès non autorisés (ex: Patients)
    // On autorise ici 'admin' ou toute autre logique de privilège.
    // Si tu veux vraiment que TOUT LE MONDE accède, laisse vide, 
    // mais attention à la sécurité de tes données.
    $allowedRoles = ['admin', 'gestionnaire']; 
    if (!in_array($user['role'], $allowedRoles)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Action non autorisée pour votre profil']);
        exit;
    }
    
    return $user;
}