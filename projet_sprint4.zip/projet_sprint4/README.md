# Sprint 4 — Administration Médecins & Utilisateurs

## Description

Module d'administration permettant à l'administrateur de gérer médecins et utilisateurs de la plateforme médicale.

## Architecture du projet

```
projet_sprint4/
├── views/admin/
│   ├── dashboard.html        ← Dashboard admin (Alee, 4h)
│   ├── users.html            ← Liste & filtres utilisateurs (Alee, 3h)
│   └── form-medecin.html     ← Formulaire médecin (Asma, 3h)
│
├── js/
│   ├── admin.js              ← JS dashboard + gestion utilisateurs (Alee)
│   ├── admin-forms.js        ← JS formulaires médecin (Asma)
│   └── admin-confirm.js      ← Modale confirmation générique (Asma, 1h)
│
├── middleware/
│   └── admin.php             ← Middleware accès admin uniquement (Sawssen, 1h)
│
├── api/admin/
│   ├── toggle-user.php       ← POST activation/désactivation (Sawssen, 2h)
│   ├── medecins.php          ← CRUD médecins (Yahya, 3h)
│   └── users.php             ← CRUD utilisateurs (Yahya, 3h)
│
├── database/
│   └── database.sql          ← Schéma BDD + trigger cascade (Rayen, 2h)
│
├── docs/
│   └── schema-bdd.md         ← Documentation schéma BDD (Rayen, 1h)
│
├── tests/
│   └── admin-tests.md        ← Plan de tests CRUD admin (Mouhib, 2h)
│
├── config/
│   ├── database.php          ← Connexion PDO
│   └── jwt.php               ← Génération/vérification JWT
│
└── css/
    └── admin.css             ← Styles interface admin
```

## Répartition équipe

| Membre   | Tâches                                                      | Durée |
|---------|-------------------------------------------------------------|-------|
| Alee    | Dashboard admin, Interface liste & filtre utilisateurs      | 7h    |
| Asma    | Formulaire médecin, Confirmation suppression (modale)       | 4h    |
| Sawssen | Middleware admin-only, API toggle activation                | 3h    |
| Yahya   | API CRUD médecins (admin), API CRUD utilisateurs (admin)    | 6h    |
| Mouhib  | Tests CRUD admin (médecins & users)                         | 2h    |
| Rayen   | Gestion suppression médecin (cascade), Sauvegarde BDD + doc | 3h   |

**Total Sprint 4 : ~25h**

## Endpoints API

| Méthode | Endpoint                       | Description                    |
|--------|-------------------------------|--------------------------------|
| GET    | /api/admin/medecins            | Lister tous les médecins       |
| POST   | /api/admin/medecins            | Créer un médecin               |
| PUT    | /api/admin/medecins/:id        | Modifier un médecin            |
| DELETE | /api/admin/medecins/:id        | Supprimer un médecin (soft)    |
| GET    | /api/admin/users               | Lister utilisateurs (+ filtres)|
| POST   | /api/admin/users               | Créer un utilisateur           |
| PUT    | /api/admin/users/:id           | Modifier un utilisateur        |
| DELETE | /api/admin/users/:id           | Supprimer un utilisateur       |
| POST   | /api/admin/toggle-user         | Activer/désactiver un compte   |

## Installation

1. Importer `database/database.sql` dans MySQL/MariaDB
2. Copier `config/database.php` et configurer les variables d'environnement :
   - `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`
   - `JWT_SECRET`
3. Servir avec PHP >= 8.0
4. Ouvrir `/admin/dashboard`

## Dépendances

- Sprint 1 (Authentification + JWT)
- PHP >= 8.0
- MySQL / MariaDB >= 8.0
