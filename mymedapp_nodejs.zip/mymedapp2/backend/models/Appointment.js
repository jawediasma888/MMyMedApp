const mongoose = require('mongoose');

const AppointmentSchema = new mongoose.Schema({
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref:  'User',
    required: true,
  },
  medecin: {
    type: mongoose.Schema.Types.ObjectId,
    ref:  'User',
    required: true,
  },
  date:       { type: Date,   required: true },
  heureDebut: { type: String, required: true }, // ex: "09:00"
  heureFin:   { type: String, required: true }, // ex: "09:30"
  statut: {
    type:    String,
    enum:    ['en_attente', 'confirme', 'annule'],
    default: 'en_attente',
  },
  motif: { type: String, trim: true },
  notes: { type: String },
}, { timestamps: true });

// Index pour éviter les doublons de créneaux
AppointmentSchema.index({ medecin: 1, date: 1, heureDebut: 1 }, { unique: true });

module.exports = mongoose.model('Appointment', AppointmentSchema);
