const Appointment = require('../models/Appointment');
const User        = require('../models/User');

// GET /api/appointments  – liste selon le rôle
exports.getAppointments = async (req, res) => {
  try {
    let filter = {};
    if (req.user.role === 'patient')  filter = { patient: req.user._id };
    if (req.user.role === 'medecin')  filter = { medecin: req.user._id };
    // admin : pas de filtre

    const { date } = req.query;
    if (date) {
      const start = new Date(date);
      const end   = new Date(date);
      end.setDate(end.getDate() + 1);
      filter.date = { $gte: start, $lt: end };
    }

    const appointments = await Appointment.find(filter)
      .populate('patient', 'nom prenom telephone')
      .populate('medecin', 'nom prenom specialite')
      .sort({ date: 1, heureDebut: 1 });

    res.json({ success: true, count: appointments.length, appointments });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/appointments/:id
exports.getAppointmentById = async (req, res) => {
  try {
    const appt = await Appointment.findById(req.params.id)
      .populate('patient', 'nom prenom telephone email')
      .populate('medecin', 'nom prenom specialite');

    if (!appt) return res.status(404).json({ error: 'Rendez-vous introuvable.' });

    // Vérification d'accès
    const uid = req.user._id.toString();
    if (req.user.role !== 'admin' &&
        appt.patient._id.toString() !== uid &&
        appt.medecin._id.toString() !== uid) {
      return res.status(403).json({ error: 'Accès refusé.' });
    }

    res.json({ success: true, appointment: appt });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/appointments
exports.createAppointment = async (req, res) => {
  try {
    const { medecin, date, heureDebut, heureFin, motif } = req.body;
    if (!medecin || !date || !heureDebut || !heureFin)
      return res.status(400).json({ error: 'Champs obligatoires manquants.' });

    const medecinDoc = await User.findById(medecin);
    if (!medecinDoc || medecinDoc.role !== 'medecin')
      return res.status(400).json({ error: 'Médecin invalide.' });

    const appt = await Appointment.create({
      patient: req.user._id,
      medecin,
      date,
      heureDebut,
      heureFin,
      motif,
    });

    res.status(201).json({ success: true, appointment: appt });
  } catch (err) {
    if (err.code === 11000)
      return res.status(409).json({ error: 'Ce créneau est déjà réservé.' });
    res.status(500).json({ error: err.message });
  }
};

// PUT /api/appointments/:id
exports.updateAppointment = async (req, res) => {
  try {
    const appt = await Appointment.findById(req.params.id);
    if (!appt) return res.status(404).json({ error: 'Rendez-vous introuvable.' });

    const uid = req.user._id.toString();
    if (req.user.role === 'patient' && appt.patient.toString() !== uid)
      return res.status(403).json({ error: 'Accès refusé.' });

    const allowed = ['statut', 'motif', 'notes', 'heureDebut', 'heureFin', 'date'];
    allowed.forEach(field => {
      if (req.body[field] !== undefined) appt[field] = req.body[field];
    });

    await appt.save();
    res.json({ success: true, appointment: appt });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE /api/appointments/:id
exports.deleteAppointment = async (req, res) => {
  try {
    const appt = await Appointment.findById(req.params.id);
    if (!appt) return res.status(404).json({ error: 'Rendez-vous introuvable.' });

    const uid = req.user._id.toString();
    if (req.user.role === 'patient' && appt.patient.toString() !== uid)
      return res.status(403).json({ error: 'Accès refusé.' });

    await appt.deleteOne();
    res.json({ success: true, message: 'Rendez-vous supprimé.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
