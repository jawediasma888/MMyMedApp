const User        = require('../models/User');
const Appointment = require('../models/Appointment');

// GET /api/admin/users
exports.getAllUsers = async (req, res) => {
  try {
    const { role } = req.query;
    const filter = role ? { role } : {};
    const users  = await User.find(filter).select('-password').sort({ createdAt: -1 });
    res.json({ success: true, count: users.length, users });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/admin/users/:id
exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PUT /api/admin/users/:id
exports.updateUser = async (req, res) => {
  try {
    const allowed = ['nom', 'prenom', 'email', 'role', 'specialite', 'telephone'];
    const updates = {};
    allowed.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });

    const user = await User.findByIdAndUpdate(req.params.id, updates, {
      new: true, runValidators: true,
    }).select('-password');

    if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE /api/admin/users/:id
exports.deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ error: 'Utilisateur introuvable.' });
    // Supprime aussi ses RDV
    await Appointment.deleteMany({
      $or: [{ patient: req.params.id }, { medecin: req.params.id }],
    });
    res.json({ success: true, message: 'Utilisateur et ses RDV supprimés.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/admin/stats
exports.getStats = async (req, res) => {
  try {
    const [totalUsers, totalMedecins, totalPatients, totalRDV, rdvParStatut] =
      await Promise.all([
        User.countDocuments(),
        User.countDocuments({ role: 'medecin' }),
        User.countDocuments({ role: 'patient' }),
        Appointment.countDocuments(),
        Appointment.aggregate([
          { $group: { _id: '$statut', count: { $sum: 1 } } },
        ]),
      ]);

    res.json({
      success: true,
      stats: { totalUsers, totalMedecins, totalPatients, totalRDV, rdvParStatut },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
