const jwt  = require('jsonwebtoken');
const User = require('../models/User');

/** Génère un JWT signé */
const generateToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });

/** Envoie le token dans un cookie HttpOnly + body */
const sendToken = (user, statusCode, res) => {
  const token = generateToken(user._id);
  const cookieOptions = {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge:   7 * 24 * 60 * 60 * 1000, // 7 jours
  };
  res.cookie('token', token, cookieOptions);
  const { password: _, ...userData } = user.toObject();
  res.status(statusCode).json({ success: true, token, user: userData });
};

// POST /api/auth/register
exports.register = async (req, res) => {
  try {
    const { nom, prenom, email, password, role, specialite, telephone } = req.body;
    if (!nom || !prenom || !email || !password) {
      return res.status(400).json({ error: 'Tous les champs obligatoires sont requis.' });
    }
    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ error: 'Email déjà utilisé.' });

    const user = await User.create({ nom, prenom, email, password, role, specialite, telephone });
    sendToken(user, 201, res);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/auth/login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: 'Email et mot de passe requis.' });

    const user = await User.findOne({ email });
    if (!user || !(await user.matchPassword(password)))
      return res.status(401).json({ error: 'Identifiants invalides.' });

    sendToken(user, 200, res);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/auth/logout
exports.logout = (req, res) => {
  res.cookie('token', '', { httpOnly: true, expires: new Date(0) });
  res.json({ success: true, message: 'Déconnexion réussie.' });
};

// GET /api/auth/me
exports.getMe = async (req, res) => {
  const user = await User.findById(req.user._id).select('-password');
  res.json({ success: true, user });
};
