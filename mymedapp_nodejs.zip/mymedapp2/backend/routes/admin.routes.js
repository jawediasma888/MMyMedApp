const express     = require('express');
const router      = express.Router();
const { protect }   = require('../middleware/auth');
const { authorize } = require('../middleware/role');
const {
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getStats,
} = require('../controllers/admin.controller');

// Toutes les routes admin sont protégées
router.use(protect, authorize('admin'));

router.get('/stats',      getStats);
router.get('/users',      getAllUsers);
router.get('/users/:id',  getUserById);
router.put('/users/:id',  updateUser);
router.delete('/users/:id', deleteUser);

module.exports = router;
