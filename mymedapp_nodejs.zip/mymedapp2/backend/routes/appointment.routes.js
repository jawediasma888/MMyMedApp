const express     = require('express');
const router      = express.Router();
const { protect }   = require('../middleware/auth');
const { authorize } = require('../middleware/role');
const {
  getAppointments,
  getAppointmentById,
  createAppointment,
  updateAppointment,
  deleteAppointment,
} = require('../controllers/appointment.controller');

router.get('/',    protect, getAppointments);
router.get('/:id', protect, getAppointmentById);
router.post('/',   protect, authorize('patient'), createAppointment);
router.put('/:id', protect, updateAppointment);
router.delete('/:id', protect, deleteAppointment);

module.exports = router;
