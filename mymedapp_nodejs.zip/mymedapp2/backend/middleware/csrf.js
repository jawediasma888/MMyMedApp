const csurf = require('csurf');

/**
 * Protection CSRF via cookie.
 * Le token CSRF doit être envoyé dans le header X-CSRF-Token
 * ou dans le corps de la requête (_csrf).
 */
const csrfProtection = csurf({
  cookie: {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'strict',
  },
});

/**
 * Endpoint helper : renvoie le token CSRF au client.
 * GET /api/csrf-token
 */
const sendCsrfToken = (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
};

/**
 * Gestionnaire d'erreur CSRF personnalisé.
 */
const csrfErrorHandler = (err, req, res, next) => {
  if (err.code === 'EBADCSRFTOKEN') {
    return res.status(403).json({ error: 'Token CSRF invalide ou manquant.' });
  }
  next(err);
};

module.exports = { csrfProtection, sendCsrfToken, csrfErrorHandler };
