/**
 * Middleware de contrôle des rôles.
 * Usage : authorize('admin'), authorize('medecin', 'admin')
 */
const authorize = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({
      error: `Accès refusé. Rôle requis : ${roles.join(' ou ')}.`,
    });
  }
  next();
};

module.exports = { authorize };
