require('dotenv').config();
const express      = require('express');
const cors         = require('cors');
const cookieParser = require('cookie-parser');
const connectDB    = require('./config/db');
const { csrfProtection, sendCsrfToken, csrfErrorHandler } = require('./middleware/csrf');

// Routes
const authRoutes        = require('./routes/auth.routes');
const appointmentRoutes = require('./routes/appointment.routes');
const adminRoutes       = require('./routes/admin.routes');

const app = express();

// --- Connexion base de données ---
connectDB();

// --- Middlewares globaux ---
app.use(cors({
  origin:      process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// --- Protection CSRF ---
app.use(csrfProtection);
app.get('/api/csrf-token', sendCsrfToken);

// --- Routes API ---
app.use('/api/auth',         authRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/admin',        adminRoutes);

// --- Fichiers statiques frontend ---
const path = require('path');
app.use(express.static(path.join(__dirname, '../frontend')));

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// --- Gestion erreur CSRF ---
app.use(csrfErrorHandler);

// --- Gestionnaire d'erreurs global ---
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({ error: err.message || 'Erreur interne du serveur.' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Serveur démarré sur http://localhost:${PORT}`));
