/**
 * app.js – Client API helper | MyMedApp
 * Gestion du token JWT, des requêtes API et du stockage utilisateur.
 */

const App = (() => {
  const BASE = '';  // même origine (servi par Express)
  const USER_KEY  = 'mymedapp_user';
  const TOKEN_KEY = 'mymedapp_token';

  let _csrfToken = null;

  /** Récupère le token CSRF depuis le serveur (une seule fois) */
  async function _getCsrf() {
    if (_csrfToken) return _csrfToken;
    const res  = await fetch(`${BASE}/api/csrf-token`, { credentials: 'include' });
    const data = await res.json();
    _csrfToken = data.csrfToken;
    return _csrfToken;
  }

  /** Headers communs */
  async function _headers(method) {
    const h = { 'Content-Type': 'application/json' };
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) h['Authorization'] = `Bearer ${token}`;
    if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(method)) {
      h['X-CSRF-Token'] = await _getCsrf();
    }
    return h;
  }

  /** Requête générique */
  async function _request(method, url, body) {
    const res = await fetch(BASE + url, {
      method,
      credentials: 'include',
      headers: await _headers(method),
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `Erreur ${res.status}`);
    return data;
  }

  const get    = (url)         => _request('GET',    url);
  const post   = (url, body)   => _request('POST',   url, body);
  const put    = (url, body)   => _request('PUT',    url, body);
  const remove = (url)         => _request('DELETE', url);

  /** Persiste l'utilisateur après login/register */
  function saveUser(data) {
    localStorage.setItem(USER_KEY,  JSON.stringify(data));
    localStorage.setItem(TOKEN_KEY, data.token);
  }

  /** Récupère l'utilisateur en session */
  function getUser() {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY));
    } catch {
      return null;
    }
  }

  /** Supprime la session */
  function clearUser() {
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(TOKEN_KEY);
    _csrfToken = null;
  }

  return { get, post, put, remove, saveUser, getUser, clearUser };
})();
