# Tests – Planning Médecin (Sprint 3)
**Responsable :** Mouhib  
**Module :** `tests/planning-tests.md`

---

## 1. Cas limites – Navigation par date

| # | Scénario | Données | Résultat attendu |
|---|----------|---------|-----------------|
| T-01 | Navigation au 1er janvier (début d'année) | Clic "précédent" depuis le 01/01 | Passe au 31/12 de l'année précédente |
| T-02 | Navigation au 31 décembre | Clic "suivant" depuis le 31/12 | Passe au 01/01 de l'année suivante |
| T-03 | Jour sans disponibilité définie | Samedi/dimanche sans dispo | Grille vide, message "Aucune disponibilité" |
| T-04 | Jour férié sans RDV | 01/01, planning vide | Tous les créneaux affichés comme "Libre" |

---

## 2. Cas limites – Créneaux libres/occupés

| # | Scénario | Données | Résultat attendu |
|---|----------|---------|-----------------|
| T-05 | RDV chevauchant exactement un créneau | RDV 09:00–09:30 / créneau 09:00–09:30 | Créneau marqué "Occupé" |
| T-06 | RDV débordant sur deux créneaux | RDV 09:15–09:45 | Les deux créneaux concernés marqués "Occupé" |
| T-07 | Disponibilité avec conflit détecté | `a_conflit = 1` retourné par l'API | Créneau affiché en orange (classe `creneau-conflit`) |
| T-08 | Aucun RDV, toutes dispo actives | Journée vierge | Tous créneaux affichés "Libre" (fond vert) |
| T-09 | Journée complète (0 créneau libre) | Tous créneaux occupés | Stat "Créneaux libres" = 0 |

---

## 3. Cas limites – API `rdv-list.php`

| # | Scénario | Paramètre | Résultat attendu |
|---|----------|-----------|-----------------|
| T-10 | Appel sans filtre date | `GET /rdv-list.php` | Liste complète des RDV du médecin |
| T-11 | Filtre date valide | `?date=2026-04-21` | Seuls les RDV du 21/04/2026 |
| T-12 | Filtre date invalide | `?date=abc` | Retour JSON `[]` (liste vide, pas d'erreur 500) |
| T-13 | Médecin non connecté | Session expirée | HTTP 401 + `{ "error": "Non authentifié." }` |
| T-14 | Médecin sans RDV | Médecin nouveau | `{ "rendez_vous": [] }` |

---

## 4. Cas limites – API `disponibilites.php`

| # | Scénario | Action | Résultat attendu |
|---|----------|--------|-----------------|
| T-15 | Ajout dispo chevauchante | POST même jour/heure | Insertion réussie (la détection conflit est informative) |
| T-16 | Suppression dispo inexistante | DELETE id=9999 | HTTP 200 + success (0 rows affected, pas d'erreur) |
| T-17 | Suppression dispo d'un autre médecin | DELETE dispo appartenant à médecin B | HTTP 200 mais 0 suppression (WHERE filtre medecin_id) |
| T-18 | GET sans session | Appel non authentifié | HTTP 401 |

---

## 5. Tests d'intégration UI

| # | Scénario | Action utilisateur | Résultat attendu |
|---|----------|--------------------|-----------------|
| T-19 | Dashboard chargement initial | Ouverture de `dashboard.html` | Planning du jour affiché, stats mises à jour |
| T-20 | Navigation prev/next | 3 clics "suivant" | Date avance de 3 jours, planning rechargé à chaque clic |
| T-21 | Filtre RDV par date | Saisie date + clic "Filtrer" | Tableau mis à jour avec RDV de la date sélectionnée |
| T-22 | Reset filtre | Clic "Réinitialiser" | Tous les RDV rechargés, champ date vidé |
| T-23 | Déconnexion | Clic "Déconnexion" | Session supprimée, redirection vers `index.html` |

---

## 6. Tests de performance (Vue SQL – Rayen)

| # | Scénario | Métrique | Seuil acceptable |
|---|----------|----------|-----------------|
| T-24 | Vue SQL planning médecin par jour | 1 000 RDV en base | Réponse < 200 ms |
| T-25 | API disponibilités + conflit | 50 disponibilités | Réponse < 100 ms |
| T-26 | Chargement dashboard complet | Réseau local | < 1 s (3 appels API parallèles) |

---

## Résultats

| Test | Statut | Commentaire |
|------|--------|-------------|
| T-01 à T-26 | ⬜ À exécuter | Sprint 3 en cours |

> **Convention :** ✅ Passé · ❌ Échoué · ⚠️ Partiel · ⬜ À tester
