<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if (!isset($_SESSION['medecin_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Non authentifié.']);
    exit;
}

$medecin_id = $_SESSION['medecin_id'];
$pdo        = getConnection();

// GET: list disponibilités with conflict detection (Vue SQL optimisée - Rayen)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->prepare(
        'SELECT d.id, d.jour_semaine, d.heure_debut, d.heure_fin,
                CASE
                    WHEN EXISTS (
                        SELECT 1 FROM rendez_vous r
                        WHERE r.medecin_id = d.medecin_id
                          AND DAYOFWEEK(r.date_rdv) = d.jour_semaine
                          AND r.heure_debut < d.heure_fin
                          AND r.heure_fin > d.heure_debut
                    ) THEN 1 ELSE 0
                END AS a_conflit
         FROM disponibilites d
         WHERE d.medecin_id = ?
         ORDER BY d.jour_semaine, d.heure_debut'
    );
    $stmt->execute([$medecin_id]);
    echo json_encode(['success' => true, 'disponibilites' => $stmt->fetchAll()]);

// POST: add a disponibilité
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data        = json_decode(file_get_contents('php://input'), true);
    $jour        = (int)($data['jour_semaine'] ?? 0);
    $heure_debut = $data['heure_debut'] ?? '';
    $heure_fin   = $data['heure_fin']   ?? '';

    if (!$jour || !$heure_debut || !$heure_fin) {
        http_response_code(400);
        echo json_encode(['error' => 'Données incomplètes.']);
        exit;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO disponibilites (medecin_id, jour_semaine, heure_debut, heure_fin)
         VALUES (?, ?, ?, ?)'
    );
    $stmt->execute([$medecin_id, $jour, $heure_debut, $heure_fin]);
    echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);

// DELETE: remove a disponibilité
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $id   = (int)($_GET['id'] ?? 0);
    $stmt = $pdo->prepare(
        'DELETE FROM disponibilites WHERE id = ? AND medecin_id = ?'
    );
    $stmt->execute([$id, $medecin_id]);
    echo json_encode(['success' => true]);

} else {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée.']);
}
