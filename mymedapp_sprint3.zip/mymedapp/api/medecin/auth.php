<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    $email    = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if (empty($email) || empty($password)) {
        http_response_code(400);
        echo json_encode(['error' => 'Email et mot de passe requis.']);
        exit;
    }

    $pdo  = getConnection();
    $stmt = $pdo->prepare('SELECT id, nom, prenom, email, password FROM medecins WHERE email = ?');
    $stmt->execute([$email]);
    $medecin = $stmt->fetch();

    if ($medecin && password_verify($password, $medecin['password'])) {
        $_SESSION['medecin_id']  = $medecin['id'];
        $_SESSION['medecin_nom'] = $medecin['nom'] . ' ' . $medecin['prenom'];
        unset($medecin['password']);
        echo json_encode(['success' => true, 'medecin' => $medecin]);
    } else {
        http_response_code(401);
        echo json_encode(['error' => 'Identifiants invalides.']);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée.']);
}
