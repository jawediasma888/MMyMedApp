<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

// Auth check
if (!isset($_SESSION['medecin_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Non authentifié.']);
    exit;
}

$medecin_id = $_SESSION['medecin_id'];
$pdo        = getConnection();

// Optional date filter
$date = $_GET['date'] ?? null;

if ($date) {
    $stmt = $pdo->prepare(
        'SELECT r.id, r.date_rdv, r.heure_debut, r.heure_fin, r.statut,
                p.nom, p.prenom, p.telephone
         FROM rendez_vous r
         JOIN patients p ON r.patient_id = p.id
         WHERE r.medecin_id = ? AND DATE(r.date_rdv) = ?
         ORDER BY r.heure_debut ASC'
    );
    $stmt->execute([$medecin_id, $date]);
} else {
    $stmt = $pdo->prepare(
        'SELECT r.id, r.date_rdv, r.heure_debut, r.heure_fin, r.statut,
                p.nom, p.prenom, p.telephone
         FROM rendez_vous r
         JOIN patients p ON r.patient_id = p.id
         WHERE r.medecin_id = ?
         ORDER BY r.date_rdv ASC, r.heure_debut ASC'
    );
    $stmt->execute([$medecin_id]);
}

$rdvs = $stmt->fetchAll();
echo json_encode(['success' => true, 'rendez_vous' => $rdvs]);
