<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if (!isset($_SESSION['medecin_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Non authentifié.']);
    exit;
}

$medecin_id = $_SESSION['medecin_id'];
$pdo        = getConnection();

// Filter by day (default: today)
$jour = $_GET['jour'] ?? date('Y-m-d');

$stmt = $pdo->prepare(
    'SELECT r.id, r.heure_debut, r.heure_fin, r.statut,
            p.nom AS patient_nom, p.prenom AS patient_prenom
     FROM rendez_vous r
     JOIN patients p ON r.patient_id = p.id
     WHERE r.medecin_id = ? AND DATE(r.date_rdv) = ?
     ORDER BY r.heure_debut ASC'
);
$stmt->execute([$medecin_id, $jour]);
$planning = $stmt->fetchAll();

echo json_encode([
    'success'  => true,
    'jour'     => $jour,
    'planning' => $planning,
]);
