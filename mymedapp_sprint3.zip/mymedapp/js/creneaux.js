/**
 * creneaux.js – Affichage des créneaux libres et occupés
 * Responsable : Asma (Sprint 3)
 */

const Creneaux = (() => {
  const HEURE_DEBUT_JOURNEE = 8;   // 08h00
  const HEURE_FIN_JOURNEE   = 18;  // 18h00
  const DUREE_CRENEAU_MIN   = 30;  // minutes

  const API_DISPO = '../../api/medecin/disponibilites.php';
  const API_RDV   = '../../api/medecin/rdv-list.php';

  /**
   * Charge et affiche les créneaux pour la date donnée.
   * @param {string} date – format YYYY-MM-DD
   */
  async function render(date) {
    const container = document.getElementById('creneaux-container');
    if (!container) return;

    container.innerHTML = '<p class="loading">Analyse des créneaux…</p>';

    try {
      const [dispoRes, rdvRes] = await Promise.all([
        fetch(API_DISPO, { credentials: 'include' }),
        fetch(`${API_RDV}?date=${date}`, { credentials: 'include' }),
      ]);

      const dispoData = await dispoRes.json();
      const rdvData   = await rdvRes.json();

      if (!dispoData.success) throw new Error(dispoData.error);
      if (!rdvData.success)   throw new Error(rdvData.error);

      const creneaux = _buildCreneaux(
        date,
        dispoData.disponibilites,
        rdvData.rendez_vous
      );

      _renderCreneaux(container, creneaux);
      _updateStats(creneaux);
    } catch (err) {
      container.innerHTML = `<p class="error">Erreur créneaux : ${err.message}</p>`;
      console.error('[Creneaux] render error:', err);
    }
  }

  /**
   * Construit la liste des créneaux (libres + occupés) pour la journée.
   */
  function _buildCreneaux(date, disponibilites, rdvs) {
    const joursemaine = new Date(date + 'T00:00:00').getDay() || 7; // 1=lun … 7=dim
    const dispoJour = disponibilites.filter(d => d.jour_semaine === joursemaine);

    const slots = [];

    dispoJour.forEach(dispo => {
      let current = _timeToMinutes(dispo.heure_debut);
      const end   = _timeToMinutes(dispo.heure_fin);

      while (current + DUREE_CRENEAU_MIN <= end) {
        const slotDebut = _minutesToTime(current);
        const slotFin   = _minutesToTime(current + DUREE_CRENEAU_MIN);
        const rdv = rdvs.find(r =>
          r.heure_debut <= slotDebut && r.heure_fin >= slotFin
        );

        slots.push({
          debut:  slotDebut,
          fin:    slotFin,
          libre:  !rdv,
          rdv:    rdv || null,
          conflit: dispo.a_conflit === 1,
        });

        current += DUREE_CRENEAU_MIN;
      }
    });

    return slots;
  }

  function _renderCreneaux(container, creneaux) {
    if (!creneaux.length) {
      container.innerHTML = '<p class="empty">Aucune disponibilité définie pour ce jour.</p>';
      return;
    }

    container.innerHTML = creneaux.map(c => {
      const cls = c.libre
        ? 'creneau creneau-libre'
        : `creneau creneau-occupe${c.conflit ? ' creneau-conflit' : ''}`;

      const content = c.libre
        ? '<span class="creneau-label">Libre</span>'
        : `<span class="creneau-patient">${c.rdv.prenom} ${c.rdv.nom}</span>
           <span class="badge badge-${c.rdv.statut}">${c.rdv.statut}</span>`;

      return `
        <div class="${cls}">
          <div class="creneau-heure">${c.debut} – ${c.fin}</div>
          ${content}
        </div>
      `;
    }).join('');
  }

  function _updateStats(creneaux) {
    const libres   = creneaux.filter(c => c.libre).length;
    const conflits = creneaux.filter(c => !c.libre && c.conflit).length;

    const elLibres   = document.getElementById('stat-libres');
    const elConflits = document.getElementById('stat-conflits');
    if (elLibres)   elLibres.textContent   = libres;
    if (elConflits) elConflits.textContent = conflits;
  }

  function _timeToMinutes(time) {
    const [h, m] = time.split(':').map(Number);
    return h * 60 + m;
  }

  function _minutesToTime(minutes) {
    const h = String(Math.floor(minutes / 60)).padStart(2, '0');
    const m = String(minutes % 60).padStart(2, '0');
    return `${h}:${m}`;
  }

  return { render };
})();
