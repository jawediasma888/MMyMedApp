/**
 * planning.js – Gestion de l'agenda / planning médecin (Sprint 3)
 * Responsable : Alee
 */

const Planning = (() => {
  const API = '../../api/medecin/planning.php';
  let _currentDate = new Date().toISOString().split('T')[0];

  /** Retourne la date courante du planning (YYYY-MM-DD) */
  function currentDate() {
    return _currentDate;
  }

  /** Charge et affiche le planning d'un jour donné */
  async function loadDay(date) {
    _currentDate = date;
    const container = document.getElementById('creneaux-container');
    if (container) container.innerHTML = '<p class="loading">Chargement…</p>';

    try {
      const res  = await fetch(`${API}?jour=${date}`, { credentials: 'include' });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Erreur serveur');
      _renderPlanning(data.planning);
      _updateStats(data.planning);
    } catch (err) {
      if (container) {
        container.innerHTML = `<p class="error">Impossible de charger le planning : ${err.message}</p>`;
      }
      console.error('[Planning] loadDay error:', err);
    }
  }

  /** Rendu interne des créneaux */
  function _renderPlanning(rdvs) {
    const container = document.getElementById('creneaux-container');
    if (!container) return;

    if (!rdvs.length) {
      container.innerHTML = '<p class="empty">Aucun rendez-vous ce jour.</p>';
      return;
    }

    container.innerHTML = rdvs.map(rdv => `
      <div class="creneau creneau-occupe">
        <div class="creneau-heure">${rdv.heure_debut} – ${rdv.heure_fin}</div>
        <div class="creneau-patient">${rdv.patient_prenom} ${rdv.patient_nom}</div>
        <span class="badge badge-${rdv.statut}">${rdv.statut}</span>
      </div>
    `).join('');
  }

  /** Met à jour les stats du dashboard */
  function _updateStats(rdvs) {
    const elRdv = document.getElementById('stat-rdv');
    if (elRdv) elRdv.textContent = rdvs.length;
  }

  return { currentDate, loadDay };
})();
