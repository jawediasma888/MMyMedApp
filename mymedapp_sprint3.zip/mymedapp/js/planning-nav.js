/**
 * planning-nav.js – Navigation par date (prev / next) dans le planning
 * Responsable : Asma (Sprint 3)
 */

const PlanningNav = (() => {
  let _currentDate = new Date().toISOString().split('T')[0];
  let _onDateChange = null;

  /**
   * Initialise la navigation entre les jours.
   * @param {string}   labelId      – id de l'élément affichant la date
   * @param {string}   prevBtnId    – id du bouton "jour précédent"
   * @param {string}   nextBtnId    – id du bouton "jour suivant"
   * @param {Function} onDateChange – callback appelé avec la nouvelle date (YYYY-MM-DD)
   */
  function init(labelId, prevBtnId, nextBtnId, onDateChange) {
    _onDateChange = onDateChange;

    const label   = document.getElementById(labelId);
    const btnPrev = document.getElementById(prevBtnId);
    const btnNext = document.getElementById(nextBtnId);

    if (!label || !btnPrev || !btnNext) {
      console.warn('[PlanningNav] Éléments DOM introuvables.');
      return;
    }

    _updateLabel(label);

    btnPrev.addEventListener('click', () => _changeDay(-1, label));
    btnNext.addEventListener('click', () => _changeDay(+1, label));
  }

  function _changeDay(delta, label) {
    const d = new Date(_currentDate);
    d.setDate(d.getDate() + delta);
    _currentDate = d.toISOString().split('T')[0];
    _updateLabel(label);
    if (typeof _onDateChange === 'function') _onDateChange(_currentDate);
  }

  function _updateLabel(label) {
    const d = new Date(_currentDate + 'T00:00:00');
    label.textContent = d.toLocaleDateString('fr-FR', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
    });
  }

  /** Retourne la date courante */
  function getDate() {
    return _currentDate;
  }

  return { init, getDate };
})();
