-- ============================================================
-- database.sql – MyMedApp | Sprint 3 Planning Médecin
-- Vue SQL planning médecin par jour + requête optimisée dispo
-- Responsable : Rayen
-- ============================================================

-- ---- Tables ----

CREATE TABLE IF NOT EXISTS medecins (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    nom        VARCHAR(100) NOT NULL,
    prenom     VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    specialite VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS patients (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    nom        VARCHAR(100) NOT NULL,
    prenom     VARCHAR(100) NOT NULL,
    email      VARCHAR(150),
    telephone  VARCHAR(20),
    date_naissance DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS disponibilites (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    medecin_id   INT NOT NULL,
    jour_semaine TINYINT NOT NULL COMMENT '1=Lundi … 7=Dimanche',
    heure_debut  TIME NOT NULL,
    heure_fin    TIME NOT NULL,
    FOREIGN KEY (medecin_id) REFERENCES medecins(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rendez_vous (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    medecin_id  INT NOT NULL,
    patient_id  INT NOT NULL,
    date_rdv    DATE NOT NULL,
    heure_debut TIME NOT NULL,
    heure_fin   TIME NOT NULL,
    statut      ENUM('en_attente','confirme','annule') DEFAULT 'en_attente',
    notes       TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (medecin_id) REFERENCES medecins(id) ON DELETE CASCADE,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- Indexes pour performances ----
CREATE INDEX idx_rdv_medecin_date  ON rendez_vous (medecin_id, date_rdv);
CREATE INDEX idx_dispo_medecin_jour ON disponibilites (medecin_id, jour_semaine);

-- ============================================================
-- VUE : planning médecin par jour (Rayen – Sprint 3)
-- Retourne tous les RDV d'un médecin avec infos patient
-- et indicateur de conflit avec les disponibilités.
-- ============================================================
CREATE OR REPLACE VIEW v_planning_medecin AS
SELECT
    r.id                                        AS rdv_id,
    r.medecin_id,
    CONCAT(m.prenom, ' ', m.nom)                AS medecin_nom,
    r.date_rdv,
    DAYOFWEEK(r.date_rdv)                       AS jour_semaine_mysql,  -- 1=dim, 2=lun … 7=sam
    -- Conversion vers convention 1=lun … 7=dim
    CASE DAYOFWEEK(r.date_rdv)
        WHEN 1 THEN 7  -- dim
        ELSE DAYOFWEEK(r.date_rdv) - 1
    END                                         AS jour_semaine,
    r.heure_debut,
    r.heure_fin,
    r.statut,
    r.notes,
    r.patient_id,
    CONCAT(p.prenom, ' ', p.nom)                AS patient_nom,
    p.telephone                                 AS patient_telephone,
    -- Conflit : le RDV sort-il de la disponibilité déclarée ?
    CASE
        WHEN NOT EXISTS (
            SELECT 1
            FROM disponibilites d
            WHERE d.medecin_id = r.medecin_id
              AND d.jour_semaine = CASE DAYOFWEEK(r.date_rdv)
                                       WHEN 1 THEN 7
                                       ELSE DAYOFWEEK(r.date_rdv) - 1
                                   END
              AND d.heure_debut <= r.heure_debut
              AND d.heure_fin   >= r.heure_fin
        ) THEN 1
        ELSE 0
    END                                         AS hors_disponibilite
FROM rendez_vous r
JOIN medecins m ON m.id = r.medecin_id
JOIN patients  p ON p.id = r.patient_id;

-- ============================================================
-- VUE : disponibilités avec détection de conflits (Rayen)
-- Utilisée par disponibilites.php (requête optimisée)
-- ============================================================
CREATE OR REPLACE VIEW v_disponibilites_conflits AS
SELECT
    d.id,
    d.medecin_id,
    d.jour_semaine,
    d.heure_debut,
    d.heure_fin,
    CASE
        WHEN EXISTS (
            SELECT 1
            FROM rendez_vous r
            WHERE r.medecin_id = d.medecin_id
              AND CASE DAYOFWEEK(r.date_rdv) WHEN 1 THEN 7 ELSE DAYOFWEEK(r.date_rdv)-1 END = d.jour_semaine
              AND r.heure_debut < d.heure_fin
              AND r.heure_fin   > d.heure_debut
        ) THEN 1
        ELSE 0
    END AS a_conflit
FROM disponibilites d;

-- ---- Données de test ----
INSERT INTO medecins (nom, prenom, email, password, specialite) VALUES
('Ben Ali',   'Sami',   'sami@mymedapp.tn',  '$2y$10$examplehashedpassword1', 'Généraliste'),
('Mansouri',  'Leila',  'leila@mymedapp.tn', '$2y$10$examplehashedpassword2', 'Cardiologue');

INSERT INTO patients (nom, prenom, email, telephone, date_naissance) VALUES
('Trabelsi', 'Ahmed',  'ahmed@mail.tn',   '+216 20 000 001', '1990-05-14'),
('Chaari',   'Fatma',  'fatma@mail.tn',   '+216 20 000 002', '1985-11-30'),
('Bouzid',   'Yassine','yassine@mail.tn', '+216 20 000 003', '2000-03-22');

INSERT INTO disponibilites (medecin_id, jour_semaine, heure_debut, heure_fin) VALUES
(1, 1, '08:00', '12:00'),  -- Lundi matin
(1, 1, '14:00', '18:00'),  -- Lundi après-midi
(1, 2, '08:00', '12:00'),  -- Mardi matin
(1, 3, '09:00', '17:00'),  -- Mercredi journée
(2, 1, '10:00', '16:00'),  -- Lundi
(2, 4, '08:00', '13:00');  -- Jeudi matin

INSERT INTO rendez_vous (medecin_id, patient_id, date_rdv, heure_debut, heure_fin, statut) VALUES
(1, 1, '2026-04-21', '09:00', '09:30', 'confirme'),
(1, 2, '2026-04-21', '10:00', '10:30', 'en_attente'),
(1, 3, '2026-04-22', '08:30', '09:00', 'confirme'),
(2, 1, '2026-04-21', '11:00', '11:30', 'confirme');
